// src/api.js
import axios from 'axios';

const apiUrl = 'https://pokeapi.co/api/v2/pokemon';

export const getPokemon = async (id) => {
  try {
    const response = await axios.get(`${apiUrl}/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching Pokémon:', error);
  }
};

// src/Pokedex.jsx
import React, { useState, useEffect } from 'react';
import { getPokemon } from './api';

const Pokedex = () => {
  const [pokemonData, setPokemonData] = useState(null);
  const [pokemonId, setPokemonId] = useState(1);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getPokemon(pokemonId);
      setPokemonData(data);
    };

    fetchData();
  }, [pokemonId]);

  const handleNextPokemon = () => {
    setPokemonId((prevId) => prevId + 1);
  };

  if (!pokemonData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="pokedex">
      <h2>{pokemonData.name}</h2>
      <img src={pokemonData.sprites.front_default} alt={pokemonData.name} />
      <button onClick={handleNextPokemon}>Next Pokémon</button>
    </div>
  );
};

export default Pokedex;
